# Release ready fixture
